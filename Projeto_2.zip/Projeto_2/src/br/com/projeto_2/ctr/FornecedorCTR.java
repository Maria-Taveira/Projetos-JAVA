
package br.com.projeto_2.ctr;

import java.sql.ResultSet;
import br.com.projeto_2.dto.FornecedorDTO;
import br.com.projeto_2.dao.FornecedorDAO;
import br.com.projeto_2.dao.ConexaoDAO;

public class FornecedorCTR {
    FornecedorDAO fornecedorDAO = new FornecedorDAO();
    
    public FornecedorCTR(){}
    
    
    public String inserirFornecedor(FornecedorDTO fornecedorDTO){
         try{
             if(fornecedorDAO.inserirFornecedor(fornecedorDTO)){
                 return "Fornecedor cadastrado com sucesso!!";
             }
             else{
                 return "Fornecdor NÃO cadastrado!";
             }
             
         }
         catch (Exception e){
             System.out.println(e.getMessage());
             return "Fornecedor NÃO cadastrado";
         }
    }
    
    public String alterarFornecedor(FornecedorDTO fornecedorDTO){
        try{
            if(fornecedorDAO.alterarFornecedor(fornecedorDTO)){
                return "Fornecedor ALTERADO com sucesso!";
            }
            else{
                return "Fornecedor NÃO alterado!";
            }
        }//fecha o try
        catch (Exception e){
            System.out.println(e.getMessage());
            return "Fornecedor NÂO alterado!";
        }//fecha o catch
    }//feccha o alterarFornecedor
    
    public String excluirFornecedor(FornecedorDTO fornecedorDTO){
        try{
            if(fornecedorDAO.excluirFornecedor(fornecedorDTO)) {
                return "Fornecedor excluído com Sucesso!";
            }
            else{
                return "Fornecedor NÂO excluído!";
            }
        }//fecha o try
        catch(Exception e){
            System.out.println(e.getMessage());
            return "Fornecedor NÂO excluído";
        }
    
    }//c=fecha o método escluirForncedor
    
    public ResultSet consultarFornecedor(FornecedorDTO fornecedorDTO, int opcao){ 
            ResultSet rs = null;
            
    rs = fornecedorDAO.consultarFornecedor(fornecedorDTO, opcao);
    return rs;
    }
    
    public void CloseDB(){
        ConexaoDAO.CloseDB();
    }//fecha o closeDB
    
    
    
}//fecha o FornecedorCTR
