package projeto;
import java.util.HashMap;
import java.util.Scanner;

public class Dicionario {

	    public static void main(String[] args) {
	    	
	        // Criand um dicionário (HashMap) (chave-valorr)
	        HashMap<String, String> dicionario = new HashMap<>();
	        Scanner scanner = new Scanner(System.in);
	        
	        int opcao;
	        
	        dicionario.put("java", "Linguagem de programação popular.");
	        dicionario.put("python", "Linguagem de programação simples e poderosa.");
	        dicionario.put("html", "Linguagem de marcação para criar páginas da web.");
	        dicionario.put("array", "Arrays são objetos semelhantes a listas que vêm com uma série de métodos embutidos para realizar operações de travessia e mutação.");
	        dicionario.put("Bubble Sort", "compara repetidamente pares de elementos adjacentes e, em seguida, trocar as suas posições se existirem na ordem errada.");
	        
	        
	        // Mostrando as palavras no dicionário
	        System.out.println("Dicionário inicial:");
		        for (String palavra : dicionario.keySet()) {
		            System.out.println(palavra + ": " + dicionario.get(palavra));
		            
		            
		            
		        }
	        
	        do {
	            // Exibe as opções do menu
	            System.out.println("\n--------- OPÇÕES ---------");
	            System.out.println("(1) Imprimir todo dicionário");
	            System.out.println("(2) Buscar palavra");
	            System.out.println("(3) Remover palavra");
	            System.out.println("(4) Inserir palavra");
	            System.out.println("(0) Sair");
	            System.out.println("--------------------------");
	            System.out.print("Digite uma opção: ");
	            opcao = scanner.nextInt();
	            scanner.nextLine(); // quebra de linha após o númeroo
	            
	            switch (opcao) {
                case 1: // Imprimir todo o dicionário
                    System.out.println("\nDicionário:");
                    if (dicionario.isEmpty()) {
                        System.out.println("O dicionário está vazio.");
                    } else {
                        for (String palavra : dicionario.keySet()) {
                            System.out.println(palavra + ": " + dicionario.get(palavra));
                        }
                    }
                    break;
                    
                case 2: // Buscar palavra
                    System.out.print("\nDigite a palavra para buscar: ");
                    String palavraBusca = scanner.nextLine();
                    if (dicionario.containsKey(palavraBusca)) {
                        System.out.println("Significado: " + dicionario.get(palavraBusca));
                    } else {
                        System.out.println("Palavra não encontrada no dicionário.");
                    }
                    break;
                    
                case 3: // Remover palavra
                    System.out.print("\nDigite a palavra para remover: ");
                    String palavraRemover = scanner.nextLine();
                    if (dicionario.remove(palavraRemover) != null) {
                        System.out.println("Palavra removida com sucesso.");
                    } else {
                        System.out.println("Palavra não encontrada no dicionário.");
                    }
                    break;
                    
                case 4: // Inserir palavra
                    System.out.print("\nDigite a palavra para adicionar: ");
                    String novaPalavra = scanner.nextLine();
                    System.out.print("Digite o significado: ");
                    String significado = scanner.nextLine();
                    dicionario.put(novaPalavra, significado);
                    System.out.println("Palavra adicionada com sucesso.");
                    break;
                
                case 0: // Sair
                    System.out.println("Saindo do programa...");
                    break;

                default:
                    System.out.println("Opção inválida. Tente novamente.");
            }
	            
	        } while (opcao != 0); // Sai quando o usuário digitar 0

	        scanner.close();
	    
	        
	        // Adicionando algumas palavras (chave-valor) ao dicionário

	    }//fecha o main
}//fecha a classe


