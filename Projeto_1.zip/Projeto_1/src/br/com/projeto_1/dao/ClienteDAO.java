
package br.com.projeto_1.dao;


import java.sql.*;
import br.com.projeto_1.dto.ClienteDTO;

public class ClienteDAO {
    
    
    public ClienteDAO(){} //método construtor da classe
    
    //atributo do tipo resultset utilizado para realizar consultas. 
    private ResultSet rs = null;
    //manipular o banco de dados
    private Statement  stmt = null; 
    
    
    public boolean inserirCliente(ClienteDTO clienteDTO){ 
        try{
        //chama o metodo que esta na classe  ConexaoDAO para abrir o banco de dados
        ConexaoDAO.ConnectDB();
       
        //Instanci o Statement que sera responsavel por executar alguma  coisa no banco de dados
        stmt = ConexaoDAO.con.createStatement();
        
        // COmando SQL que sera executado no banco de dados
        String comando = "Insert into cliente (nome_cli, logradouro_cli, numero_cli, " 
                + "bairro_cli, cidade_cli, estado_cli, cep_cli, cpf_cli, rg_cli) values(" 
                + "'" + clienteDTO.getNome_cli() + "', "
                + "'" + clienteDTO.getLogradouro_cli() + "', "
                + clienteDTO.getNumero_cli() + ", "
                + "'" + clienteDTO.getBairro_cli() + "', "
                + "'" + clienteDTO.getCidade_cli() + "', "
                + "'" + clienteDTO.getEstado_cli() + "', "
                + "'" + clienteDTO.getCep_cli() + "',"
                + "'" + clienteDTO.getCpf_cli() + "', "
                + "'" +clienteDTO.getRg_cli() + "') ";
        
        
        //Executa o comando SQL  no banco de dados
        stmt.execute(comando.toUpperCase());
        
        //Da um commit no banco de dados
        ConexaoDAO.con.commit();
        //Fecha o statement
        stmt.close();
        return true;
        }

        catch (Exception e){
            System.out.println(e.getMessage());
            return false;
        }//fecha o catch
        finally{
            ConexaoDAO.CloseBD();
        }//fecha o finally
        
    }//fecha o método InserirCliente
    
    public ResultSet consultarCliente(ClienteDTO clienteDTO, int opcao){
        try{
            //chama o método que esta na classe ConexaoDAO para abirir o banco de dados
            ConexaoDAO.ConnectDB();
            //cria o stetement que responsável por executar alguma coisa no banco de dados
            stmt = ConexaoDAO.con.createStatement();
            //comando SQL que sera executado no banco de dados
            String comando = "";      
        
            switch(opcao){
                case 1:
                    comando = "Select c.* " +
                              "from cliente c " + 
                              "Where nome_cli like '" + clienteDTO.getNome_cli() + "%' " + 
                              "order by c.nome_cli";
                break;
                case 2:
                    comando = "Select c.* " +
                              "from cliente c " +
                              "Where c.id_cli = " + clienteDTO.getId_cli();
                break;
                case 3:
                    comando = "Select c.id_cli, c.nome_cli " + 
                              "from cliente c";
                break;
            }//fecha o switch
            
            //Executa o comando SQL no banco de dados
            rs = stmt.executeQuery(comando.toUpperCase());
            return rs;
        }//fecha o try
       //caso tenha algum erro no caodio acima é enviado uma mensagem no console com oque esta acontecendo 
        
       catch (Exception e){
           System.out.println(e.getMessage());
           return rs;
       }
    }//fecha o metodo inserir
    
        public boolean alterarCliente(ClienteDTO clienteDTO){ 
            try{
            //chama o metodo que esta na classe  ConexaoDAO para abrir o banco de dados
            ConexaoDAO.ConnectDB();

            //Instanci o Statement que sera responsavel por executar alguma  coisa no banco de dados
            stmt = ConexaoDAO.con.createStatement();

            // COmando SQL que sera executado no banco de dados
            String comando = "Update cliente set "
                    + "nome_cli = '" +  clienteDTO.getNome_cli() + "', "
                    + "logradouro_cli = '" +  clienteDTO.getLogradouro_cli() + "', "
                    + "numero_cli = " +  clienteDTO.getNumero_cli() + ", "
                    + "bairro_cli = '" +  clienteDTO.getBairro_cli() + "', "
                    + "cidade_cli = '" +  clienteDTO.getCidade_cli() + "', "
                    + "estado_cli = '" +  clienteDTO.getEstado_cli() + "', "
                    + "cep_cli = '" +  clienteDTO.getCep_cli()  + "', "
                    + "cpf_cli = '" +  clienteDTO.getCpf_cli() + "', "
                    + "rg_cli = '" +  clienteDTO.getRg_cli() + "' "
                    + "where id_cli = " + clienteDTO.getId_cli(); 
                   
                    stmt.execute(comando.toUpperCase());


            //Executa o comando SQL  no banco de dados
            stmt.execute(comando.toUpperCase());

            //Da um commit no banco de dados
            ConexaoDAO.con.commit();
            //Fecha o statement
            stmt.close();
            return true;
            }

            catch (Exception e){
                System.out.println(e.getMessage());
                return false;
            }//fecha o catch
            finally{
                ConexaoDAO.CloseBD();
            }//fecha o finally

    }//fecha o metodo
    
    public boolean excluirCliente(ClienteDTO clienteDTO){ 
        try{
        //chama o metodo que esta na classe  ConexaoDAO para abrir o banco de dados
        ConexaoDAO.ConnectDB();
       
        //Instanci o Statement que sera responsavel por executar alguma  coisa no banco de dados
        stmt = ConexaoDAO.con.createStatement();
        
        // COmando SQL que sera executado no banco de dados
        String comando = "Delete from cliente where id_CLI = "
                + clienteDTO.getId_cli();
        
        //Executa o comando SQL  no banco de dados
        stmt.execute(comando.toUpperCase());
        
        //Da um commit no banco de dados
        ConexaoDAO.con.commit();
        //Fecha o statement
        stmt.close();
        return true;
        }

        catch (Exception e){
            System.out.println(e.getMessage());
            return false;
        }//fecha o catch
        finally{
            ConexaoDAO.CloseBD();
        }//fecha o finally
         
        
        
    }//fecha o método InserirCliente    
        
        
} //fecha a classe ClienteDAO





