package br.com.projeto_1.ctr;

import java.sql.ResultSet;
import br.com.projeto_1.dto.ClienteDTO;
import br.com.projeto_1.dao.ClienteDAO;
import br.com.projeto_1.dao.ConexaoDAO;

public class ClienteCTR {
    
    ClienteDAO clienteDAO = new ClienteDAO();
    
    public ClienteCTR(){}
    
    
    
    
    public String inserirCliente(ClienteDTO clienteDTO){
        try{
            //Chama o método que esta an classe DAO aguardando uma resposta(true ou false)
            if(clienteDAO.inserirCliente(clienteDTO)){
                return "Cliente Cadastrado com sucesso!";
            }//fech ao if
            else{
                return "Cliente NÃO cadastrado!";
            }//fecha o else
        }//fecha o try
        catch (Exception e){
            System.out.println(e.getMessage());
            return "Cliente NÂO Cadastrado!";
        }//fecha o catch 
        
    }//fecha  o metodo inserirCliente
    
    
    
    
    
    public ResultSet consultarCliente(ClienteDTO clienteDTO, int opcao){
        // É criado um atributo do tipo ResultSet, pois este método recebe o resultado  de uma consulta
        ResultSet rs = null;
        
        //O atributo rs recebe a consulta realizada pelo metodo da classe Dao
        rs = clienteDAO.consultarCliente(clienteDTO, opcao);
        
        return rs;
    }
    
    public void CloseDB(){
        ConexaoDAO.CloseBD();
    }
    
    
    
    
    
    public String alterarCliente(ClienteDTO clienteDTO){
        try{
            //Chama o método que esta an classe DAO aguardando uma resposta(true ou false)
            if(clienteDAO.alterarCliente(clienteDTO)){
                return "Cliente alterado com sucesso!";
            }//fech ao if
            else{
                return "Cliente NÃO alterado!";
            }//fecha o else
        }//fecha o try
        catch (Exception e){
            System.out.println(e.getMessage());
            return "Cliente NÂO alterado!";
        }//fecha o catch 
        
    }//fecha  o metodo inserirCliente
    
   
    public String excluirCliente(ClienteDTO clienteDTO){
        try{
            //Chama o método que esta an classe DAO aguardando uma resposta(true ou false)
            if(clienteDAO.excluirCliente(clienteDTO)){
                return "Cliente excluido com sucesso!";
            }//fech ao if
            else{
                return "Cliente NÃO excluido!";
            }//fecha o else
        }//fecha o try
        catch (Exception e){
            System.out.println(e.getMessage());
            return "Cliente NÂO excluido!";
        }//fecha o catch 
        
    }//fecha  o metodo inserirCliente
    
}//fecha a classe ClienteCTR
