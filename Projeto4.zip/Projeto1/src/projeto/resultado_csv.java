package projeto;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;


public class resultado_csv {
	 public static void main(String[] args) {
	        String arquivoEntrada = "entrada.csv"; // Nome do arquivo de entrada
	        String arquivoSaida = "resultado.csv"; // Nome do arquivo de saída

	        try (
	            BufferedReader br = new BufferedReader(new FileReader(arquivoEntrada));
	            FileWriter fw = new FileWriter(arquivoSaida)
	        ) {
	            String linha = br.readLine(); // Lê a primeira linha (cabeçalho)
	            
	            // Ignora o cabeçalho no cálculo e cria o cabeçalho para o arquivo de saída
	            fw.write("RESULTADO\n");

	            // Lê as demais linhas
	            while ((linha = br.readLine()) != null) {
	                String[] campos = linha.split(","); // Divide a linha pelos campos (separador ,)
	                
	                String operacao = campos[0];
	                int valor1 = Integer.parseInt(campos[1]);
	                int valor2 = Integer.parseInt(campos[2]);
	                int resultado = 0;

	                // Realiza o cálculo com base na operação
	                switch (operacao) {
	                    case "+":
	                        resultado = valor1 + valor2;
	                        break;
	                    case "-":
	                        resultado = valor1 - valor2;
	                        break;
	                    case "*":
	                        resultado = valor1 * valor2;
	                        break;
	                    case "/":
	                        // Evitar divisão por zero
	                        if (valor2 != 0) {
	                            resultado = valor1 / valor2;
	                        } else {
	                            System.out.println("Erro: Divisão por zero na linha: " + linha);
	                            resultado = 0; // Define um valor padrão
	                        }
	                        break;
	                    default:
	                        System.out.println("Operação inválida: " + operacao);
	                        break;
	                }

	                // Escreve o resultado no arquivo de saída
	                fw.write(resultado + "\n");
	            }

	            System.out.println("Arquivo resultado.csv gerado com sucesso!");
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	    }
	
}
