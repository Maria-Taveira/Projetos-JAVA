package projeto;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class entrada_csv {
    public static void main(String[] args) {
    	String arquivoEntrada = "entrada.csv"; // Nome do arquivo de entrada

        try (BufferedReader br = new BufferedReader(new FileReader(arquivoEntrada))) {
            String linha;
            
            // Lê o cabeçalho primeiro
            linha = br.readLine(); // Lê a primeira linha do arquivo (cabeçalho)
            System.out.println(linha); // Imprime o cabeçalho como no arquivo

            // Lê as demais linhas (os dados)
            while ((linha = br.readLine()) != null) {
                System.out.println(linha); // Exibe cada linha como está no CSV
            }
         } 
         catch (IOException e) {
            e.printStackTrace();
         }
	 }
}

