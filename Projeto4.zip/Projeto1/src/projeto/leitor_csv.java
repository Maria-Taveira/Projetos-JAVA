package projeto;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class leitor_csv {
	 public static void main(String[] args) {
	        String arquivoEntrada = "entrada.csv"; // Nome do arquivo de entrada

	        try (BufferedReader br = new BufferedReader(new FileReader(arquivoEntrada))) {
	            String linha;
	            while ((linha = br.readLine()) != null) {
	                // Divide a linha em partes usando a vírgula como separador
	                String[] dados = linha.split(",");
	                
	                // Mostra os dados no console (apenas para verificar)
	                System.out.println("Operação: " + dados[0] + 
	                                   ", Valor1: " + dados[1] + 
	                                   ", Valor2: " + dados[2]);
	            }
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	    }
	
	
}

